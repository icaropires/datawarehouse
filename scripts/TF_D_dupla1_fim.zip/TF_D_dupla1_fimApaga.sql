 -- --------     << TF >>     ------------
--
--                    SCRIPT DE APAGA (DML)
--
-- Data Criacao ...........: 29/10/2019
-- Autor(es) ..............: Sara Silva
--                           Ícaro Pires
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: tf_icaro_sara
--
-- Data Ultima Alteracao ..: 29/10/2019
--   => Drop das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 01 Visoes
--         => 02 usuários
--
-- -----------------------------------------------------------------


USE tf_icaro_sara;

DROP TABLE OCORRENCIA;
DROP TABLE BOLETIM;
DROP TABLE DELEGACIA;
DROP TABLE DEPARTAMENTO;

DROP VIEW V_OCORRENCIA_X_DELEGACIA;

DROP USER admin;
DROP USER usuario;
